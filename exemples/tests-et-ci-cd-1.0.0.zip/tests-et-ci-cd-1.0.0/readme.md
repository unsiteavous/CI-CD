# Tests et CI/CD
[![pipeline status](https://git.captp.fr/theophile/tests-et-ci-cd/badges/main/pipeline.svg)](https://git.captp.fr/theophile/tests-et-ci-cd/-/commits/main)

[![coverage report](https://git.captp.fr/theophile/tests-et-ci-cd/badges/main/coverage.svg)](https://git.captp.fr/theophile/tests-et-ci-cd/-/commits/main)

[![Latest Release](https://git.captp.fr/theophile/tests-et-ci-cd/-/badges/release.svg)](https://git.captp.fr/theophile/tests-et-ci-cd/-/releases)
