<?php
session_start();
require_once __DIR__ . '/Services/Autoload.php';
require_once __DIR__ . '/Services/Router.php';
